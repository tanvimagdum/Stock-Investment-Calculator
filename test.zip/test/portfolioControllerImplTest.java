import controller.portfolioController;
import controller.portfolioControllerImpl;
import org.junit.Test;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.Assert.assertEquals;

public class portfolioControllerImplTest {

  @Test
  public void testReadGetPortfolio() throws IOException {

    ArrayList<String> str = new ArrayList<>(Arrays.asList("A", "AAPL"));
    ArrayList<Float> flt = new ArrayList<>(Arrays.asList((float)10.00, (float)12.00));

    Readable in = new StringReader("Port AAPL 10 A 20 Done");

    portfolioController pc = new portfolioControllerImpl(in);
    pc.readPortfolioFile("port.csv");

    assertEquals("port",pc.getPortfolioNames()[0]);

  }

  @Test
  public void testPortfolioContents() throws IOException {

    ArrayList<String> str = new ArrayList<>(Arrays.asList("A", "AAPL"));
    ArrayList<Float> flt = new ArrayList<>(Arrays.asList((float)10.00, (float)12.00));

    Readable in = new StringReader("Port AAPL 10 A 20 Done");

    portfolioController pc = new portfolioControllerImpl(in);
    pc.readPortfolioFile("port.csv");

    assertEquals("port",pc.getPortfolioNames()[0]);

    assertEquals("Contents of Portfolio: port",pc.getPortfolioContents("port")[0] );
    assertEquals("Ticker: A; Count: 10.00", pc.getPortfolioContents("port")[1]);
    assertEquals("Ticker: AAPl; Count: 12.00", pc.getPortfolioContents("port")[2]);

  }

  @Test
  public void testPortfolioLatestValue() throws IOException {

    ArrayList<String> str = new ArrayList<>(Arrays.asList("A", "AAPL"));
    ArrayList<Float> flt = new ArrayList<>(Arrays.asList((float)10.00, (float)12.00));

    Readable in = new StringReader("Port AAPL 10 A 20 Done");

    portfolioController pc = new portfolioControllerImpl(in);
    pc.readPortfolioFile("port.csv");

    assertEquals("port",pc.getPortfolioNames()[0]);

    assertEquals("Value of Portfolio: port as of 10/31/2022",pc.getPortfolioValueLatest("port")[0] );
    assertEquals("Ticker: A; Count: 10.0; Value per: 140.89; Total Value: 1408.90", pc.getPortfolioValueLatest("port")[1]);
    assertEquals("Ticker: AAPL; Count: 12.0; Value per: 150.65; Total Value: 1807.80", pc.getPortfolioValueLatest("port")[2]);
    assertEquals("Total value of portfolio: 3216.70", pc.getPortfolioValueLatest("port")[3]);
  }

}