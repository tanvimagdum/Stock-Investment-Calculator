package controller;

/**
 * A general class for controller commands. Used for creating the maps in the controller.
 */
public interface Command {
  //this interface is empty, as the methods are unique to the extensions of this interface
}
